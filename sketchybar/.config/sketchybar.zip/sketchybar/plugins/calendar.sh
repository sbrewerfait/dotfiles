#!/usr/bin/env bash

sketchybar --set $NAME label="$(date '+%a %b %-d %-H:%M')"
# sketchybar --set $NAME label="$(date +'%a %d %b %I:%M %p')"
